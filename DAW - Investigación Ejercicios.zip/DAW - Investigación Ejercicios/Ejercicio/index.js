const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Simulando una base de datos y almacenar datos válidos
let users = [];
let tokens = []; 

// Caso 1
app.post('/api/register', (req, res) => {
    const { username, password, email } = req.body;

    // Verificar si el usuario ya existe
    const existingUser = users.find(user => user.username === username);
    if (existingUser) {
        return res.status(400).json({ message: 'El usuario ya existe' });
    }
    const newUser = { username, password, email };
    users.push(newUser);

    return res.status(201).json({ message: 'Usuario registrado correctamente', user: newUser });
});

// Caso 2
app.post('/api/login', (req, res) => {
    const { username, password } = req.body;

    const user = users.find(user => user.username === username);
    if (!user || user.password !== password) {
        return res.status(401).json({ message: 'Credenciales incorrectas' });
    }
    const token = `${username}-token`;
    tokens.push(token);

    return res.status(200).json({ 
        message: 'Inicio de sesión exitoso', 
        token: token, 
        user: {
            username: user.username,
            email: user.email
        }
    });
});

// Middleware para verificar la autenticación
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token || !tokens.includes(token)) {
        return res.status(403).json({ message: 'Token no válido o inexistente' });
    }

    const user = users.find(user => `${user.username}-token` === token);
    if (!user) {
        return res.status(403).json({ message: 'Token no válido o inexistente' });
    }
    
    req.user = user;
    next();
};

// Caso 3
app.get('/api/protected-resource', (req, res) => { 
    res.status(200).json({ 
        message: 'Authorization": Bearer token_valido'
    });
});

// Caso 4
app.post('/api/logout', (req, res) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (!token || !tokens.includes(token)) {
        return res.status(200).json({ message: 'Authorization: Bearer token_valido' });
    }
});

// Mensaje de bienvenida al conectar con localhost
app.get('/', (req, res) => {
    res.status(200).send("Bienvenido");
});

// Ruta de registro de usuario (Información general)
app.get('/api/registro', (req, res) => {
    res.status(200).json({ message: "usuario, contraseña, correo" });
});

// Iniciar el servidor
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
